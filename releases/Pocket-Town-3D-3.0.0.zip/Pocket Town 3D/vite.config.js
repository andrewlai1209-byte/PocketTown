import {defineConfig} from 'vite';
export default defineConfig({
  base: './',
  server: {host: '127.0.0.1', port: 5173},
  build: {
    target: 'es2020',
    assetsDir: 'assets',
    rollupOptions: {
      output: {
        manualChunks(id) {
          if (id.includes('node_modules/three') || id.includes('node_modules\\three')) return 'engine';
          if (id.includes('/src/sim/')) return 'simulation';
        }
      }
    }
  }
});
