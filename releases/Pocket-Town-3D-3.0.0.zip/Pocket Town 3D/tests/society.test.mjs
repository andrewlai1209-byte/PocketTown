import test from 'node:test';
import assert from 'node:assert/strict';
import {Game} from '../src/sim/game.js';

test('citizens follow work and leisure schedules',()=>{
 const game=new Game(),baker=game.citizens[0];
 game.state.minute=9*60;assert.deepEqual(game.schedule(baker),[-18,-7.5]);
 game.state.minute=12*60;assert.deepEqual(game.schedule(baker),[18,6.5]);
 game.state.minute=21*60;assert.deepEqual(game.schedule(baker),baker.home);
});

test('a broken promise changes relationships, memories, rumors and town trust',()=>{
 const game=new Game(),soc=game.society,from=game.citizens[5],to=game.citizens[0];
 const before=soc.relation(from,to),trust=game.state.trust;
 soc.data.promises.push({from:from.id,to:to.id,due:2,kind:'supplies',status:'open'});
 game.state.day=2;soc.random=()=>0;soc.resolvePromises();
 assert.equal(soc.data.promises.at(-1).status,'betrayed');
 assert.ok(soc.relation(from,to)<before);
 assert.ok(game.state.trust<trust);
 assert.match(soc.agent(to).memories[0],/broke a promise/);
 assert.equal(soc.data.rumors[0].subject,from.id);
 assert.equal(soc.data.incidents[0].type,'betrayal');
});

test('player dialogue can request a promise and receive its consequence',()=>{
 const game=new Game(),soc=game.society,c=game.citizens[0];
 game.state.friendships[c.name]=40;
 assert.match(soc.dialogue(c,'promise'),/promise/);
 assert.equal(soc.data.promises.at(-1).to,'player');
 game.state.day=2;soc.random=()=>.99;soc.resolvePromises();
 assert.equal(soc.data.promises.at(-1).status,'kept');
 assert.equal(game.state.supplies,10);
});
