# Pocket Town 3D — Society Sandbox

An English-language 3D game with twelve autonomous citizens, jobs, schedules, memories, friendships, rumors, promises and betrayal.

## Play the included build

1. Extract the ZIP completely into a folder.
2. Install Node.js 20.19+ if it is not already available.
3. Double-click **Start Game.cmd** on Windows.
4. Keep the launcher window open while playing. The game opens in your browser.

The included build does not need `npm install` or an internet connection. The launcher serves the files in `dist/` through a local, read-only server. It starts at port 4173 and selects another port if needed. To stop, press Ctrl+C in the launcher window.

On macOS or Linux, run `node scripts/serve.mjs --open` from the extracted folder.

Do not open the HTML file directly. The game uses multiple JavaScript and CSS files, which should be loaded through the launcher.

## Controls

- Drag: orbit the camera. Scroll: zoom.
- WASD or arrow keys: walk relative to the camera.
- Click ground: walk to a point.
- Click a person or building: interact.
- E: interact with a nearby person or place. Esc: close the panel.
- Society: inspect relationships, promises, trust and town events.
- Top-right buttons: pause, speed and fullscreen.

Progress is saved locally in your browser. Use the same preview address to continue a save.

## Edit the project

```bash
npm install
npm run dev
```

Open the address printed by Vite. There is one development entry: the root `index.html`.

```bash
npm run build       # Generate the multi-file playable build in dist/
npm run preview     # Serve that build locally
npm test            # Run simulation regression checks
npm run package     # Build and produce releases/Pocket-Town-3D-3.0.0.zip
```

The release includes source, build, launcher, documentation and dependency lockfile. It excludes `node_modules` and older release ZIPs.

See [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) for the module map. Third-party licenses are in `licenses/`.

Citizen decisions use local behavior rules and contextual English dialogue. No online AI account or API key is required.
