# Architecture

Pocket Town is an English-language 3D browser game with a modular source project and a separate playable build.

## Runtime

1. `Start Game.cmd` starts `scripts/serve.mjs` using Node's built-in HTTP server.
2. The server serves only `dist/` on the loopback interface. It does not expose the source project or accept writes.
3. `dist/index.html` loads external CSS and JavaScript files from `dist/assets/`.
4. `src/main.js` boots `core/Application` and presents a visible error if initialization fails.
5. Application coordinates input, simulation, rendering, the HUD, and periodic saves.

## Modules

| Folder | Responsibility |
| --- | --- |
| `src/core/` | Application startup and frame lifecycle |
| `src/input/` | Pointer picking and camera-relative keyboard movement |
| `src/world/` | Three.js scene, geometry, lighting, shadows and camera |
| `src/data/` | Citizen identities, jobs, homes and town places |
| `src/sim/` | Clock, economy, citizen schedules and social simulation |
| `src/services/` | Versioned local save data and migration |
| `src/ui/` | HUD, dialogue choices and society reports |
| `src/styles/` | Responsive visual interface |
| `scripts/` | Preview and ZIP release commands |
| `tests/` | Social and schedule regression checks |

## Society simulation

Each of twelve citizens has a job, daily schedule, personality, needs, relationships, memories and current goal. Hourly encounters can create cooperation, conflict, trades or promises. Promise outcomes depend on personality and pressure. Betrayal changes trust and relationships, creates memories and rumors, and appears in society reports. This is a local autonomous behavior simulation with contextual English dialogue; it does not call a language-model service.

## Source and release

The root `index.html` is a small development entry. Vite compiles the source into a separate HTML entry, game modules, simulation module, 3D engine module and stylesheet. The ZIP includes the playable build and editable source. It excludes `node_modules`, previous archives and temporary files. No dependency installation is required to run the included build; Node.js is required for the local preview server.

Opening HTML directly through `file://` can prevent browser modules from loading. The entry page therefore explains how to use the launcher. Preview uses HTTP and the same build included in the ZIP.
