export const places=[
{name:'Town Hall',type:'civic',x:0,z:-15,w:11,d:8,h:9,color:0xe4d8bd,roof:0x708ca3,icon:'🏛️',description:'The center of public life and community decisions.'},
{name:'Bakery',type:'bakery',x:-18,z:-13,w:8,d:7,h:6,color:0xf0bf9d,roof:0xb96c61,icon:'🥐',description:'Fresh bread keeps the town fed.'},
{name:'Clinic',type:'clinic',x:18,z:-13,w:8,d:7,h:7,color:0xe6eee7,roof:0x6aafb0,icon:'🏥',description:'Care and recovery for everyone.'},
{name:'School',type:'school',x:-18,z:1,w:10,d:8,h:7,color:0xe6d19f,roof:0xc98962,icon:'🏫',description:'Learning for children and adults.'},
{name:'Café',type:'cafe',x:18,z:1,w:8,d:7,h:6,color:0xeebfae,roof:0x9e7798,icon:'☕',description:'A place to rest and meet your neighbors.'},
{name:'Farm',type:'farm',x:-19,z:17,w:11,d:8,h:5,color:0xccac74,roof:0x927c59,icon:'🌾',description:'Grow crops for the local food supply.'},
{name:'Market',type:'market',x:18,z:17,w:10,d:8,h:6,color:0xc4ded0,roof:0x6ca396,icon:'🛒',description:'Everyday food and essential goods.'},
{name:'Workshop',type:'workshop',x:-4,z:20,w:8,d:7,h:6,color:0xbfc4c0,roof:0x637d8e,icon:'🛠️',description:'Repair and create useful things.'},
{name:'Library',type:'library',x:8,z:20,w:9,d:7,h:7,color:0xdbc9ab,roof:0x8196b3,icon:'📚',description:'Stories, knowledge, and a quiet place to think.'}
];
export const citizens=[
{name:'Mira',role:'Baker',work:'Bakery',home:[-27,-23],color:0xe77f77,lines:['The first loaf is always the best.','Good bread brings people together.']},
{name:'Noah',role:'Doctor',work:'Clinic',home:[-18,-23],color:0x7ab8ac,lines:['Take a break before you need one.','A healthy town is a happy town.']},
{name:'Ada',role:'Teacher',work:'School',home:[18,-23],color:0x907db6,lines:['Curiosity is our best resource.','The students taught me something today.']},
{name:'Leo',role:'Barista',work:'Café',home:[27,-23],color:0xc285a4,lines:['Every cup comes with a story.','The lunch rush is almost here.']},
{name:'Ivy',role:'Farmer',work:'Farm',home:[-28,7],color:0xa5b669,lines:['The soil tells me what it needs.','We should share this harvest.']},
{name:'June',role:'Shopkeeper',work:'Market',home:[28,7],color:0xe0a459,lines:['Fresh produce just arrived!','Neighbors keep this shop alive.']},
{name:'Finn',role:'Maker',work:'Workshop',home:[-27,28],color:0x799fbb,lines:['I can fix almost anything.','Making things beats throwing them out.']},
{name:'Sage',role:'Librarian',work:'Library',home:[-17,28],color:0xa18bbb,lines:['A new story is waiting for you.','The library belongs to everyone.']},
{name:'Wren',role:'Mail Carrier',work:'Town Hall',home:[18,28],color:0xe0b86c,lines:['I know every road in this town.','Messages keep us connected.']},
{name:'Mayor Ellis',role:'Mayor',work:'Town Hall',home:[27,28],color:0x708ba6,lines:['A town is only as strong as its people.','We have a lot to build together.']},
{name:'Pip',role:'Student',work:'School',home:[-28,-5],color:0xe6a0a5,lines:['I learned about bees today!','After class, I am going to the park.']},
{name:'Nana Rose',role:'Retired Neighbor',work:'Park',home:[28,-5],color:0xb49abb,lines:['I remember when this was all fields.','Pull up a chair and tell me your story.']}
];
