const KEY = 'pocket-town-3d';

export function loadState(defaults) {
  try {
    const stored = JSON.parse(localStorage.getItem(KEY));
    const raw = stored?.state || stored;
    if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return defaults;
    const state = {...defaults};
    for (const key of ['day', 'minute', 'money', 'food', 'energy', 'mood', 'trust', 'reputation', 'supplies', 'speed']) {
      if (Number.isFinite(raw[key])) state[key] = raw[key];
    }
    state.day = Math.max(1, Math.floor(state.day));
    state.minute = Math.max(0, Math.min(1439, Math.floor(state.minute)));
    state.speed = [1, 2, 4].includes(state.speed) ? state.speed : 1;
    for (const key of ['food', 'energy', 'mood', 'trust']) state[key] = Math.max(0, Math.min(100, state[key]));
    for (const key of ['friendships', 'shifts']) {
      if (raw[key] && typeof raw[key] === 'object' && !Array.isArray(raw[key])) {
        state[key] = Object.fromEntries(Object.entries(raw[key]).filter(([, value]) => Number.isFinite(value)));
      }
    }
    state.log = Array.isArray(raw.log) ? raw.log.filter(item => typeof item === 'string').slice(0, 20) : [];
    if (raw.society && typeof raw.society === 'object') state.society = raw.society;
    return state;
  } catch {
    return defaults;
  }
}

export function saveState(state) {
  try {
    localStorage.setItem(KEY, JSON.stringify({version: 3, state}));
    return true;
  } catch {
    return false;
  }
}
