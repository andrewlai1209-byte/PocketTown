import {Game} from '../sim/game.js';
import {World} from '../world/scene.js';
import {UI} from '../ui/ui.js';
import {Controls} from '../input/controls.js';

export class Application {
  constructor() {
    this.game = new Game();
    this.world = new World(document.getElementById('scene'), this.game);
    this.ui = new UI(this.game, this.world);
    this.input = new Controls(this);
    this.active = false;
    this.lastFrame = performance.now();
    this.hudElapsed = 0;
    this.saveElapsed = 0;
    document.getElementById('play').addEventListener('click', () => {
      document.getElementById('start').hidden = true;
      document.getElementById('start').style.display = 'none';
      this.active = true;
      this.ui.toast('Welcome to Pocket Town! Meet a neighbor or open Society.');
    });
    addEventListener('pagehide', () => this.game.save());
    document.addEventListener('visibilitychange', () => {
      this.lastFrame = performance.now();
      if (document.hidden) this.game.save();
    });
    this.frame = this.frame.bind(this);
  }

  start() {
    document.documentElement.dataset.ready = 'true';
    requestAnimationFrame(this.frame);
  }

  frame(now) {
    const dt = Math.min(50, now - this.lastFrame);
    this.lastFrame = now;
    if (!document.hidden) {
      if (this.active && !this.game.state.paused) {
        this.input.update();
        this.game.tick(dt);
      }
      this.world.update(this.game.state.paused ? 0 : dt);
      this.hudElapsed += dt;
      this.saveElapsed += dt;
      if (this.hudElapsed >= 250) {
        this.ui.stats();
        this.hudElapsed = 0;
      }
      if (this.active && this.saveElapsed >= 15000) {
        this.game.save();
        this.saveElapsed = 0;
      }
    }
    requestAnimationFrame(this.frame);
  }
}
