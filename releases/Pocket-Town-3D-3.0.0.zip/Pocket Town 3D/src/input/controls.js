import {places} from '../data/town.js';

export class Controls {
  constructor(app) {
    this.app = app;
    this.keys = new Set();
    this.pointer = null;
    const canvas = app.world.renderer.domElement;
    canvas.addEventListener('pointerdown', event => {
      if (event.button === 0) this.pointer = {x: event.clientX, y: event.clientY};
    });
    canvas.addEventListener('pointercancel', () => { this.pointer = null; });
    canvas.addEventListener('pointerup', event => {
      const down = this.pointer;
      this.pointer = null;
      if (!app.active || !down || Math.hypot(event.clientX - down.x, event.clientY - down.y) > 7) return;
      const hit = app.world.pick(event.clientX, event.clientY);
      if (!hit) return;
      const {kind, ref} = hit.object.userData;
      if (kind === 'ground') {
        app.world.moveTo(hit.point.x, hit.point.z);
        app.ui.close();
      } else if (kind === 'citizen') app.ui.citizen(ref);
      else if (kind === 'place') app.ui.place(ref);
    });
    addEventListener('keydown', event => {
      if (!app.active || /INPUT|TEXTAREA|SELECT/.test(event.target.tagName)) return;
      const key = event.key.toLowerCase();
      if (['w', 'a', 's', 'd', 'arrowup', 'arrowleft', 'arrowdown', 'arrowright'].includes(key)) {
        event.preventDefault();
        this.keys.add(key);
      }
      if (key === 'e' && !event.repeat) this.interact();
      if (key === 'escape') app.ui.close();
    });
    addEventListener('keyup', event => this.keys.delete(event.key.toLowerCase()));
    addEventListener('blur', () => this.keys.clear());
  }

  update() {
    const forward = Number(this.keys.has('w') || this.keys.has('arrowup')) - Number(this.keys.has('s') || this.keys.has('arrowdown'));
    const side = Number(this.keys.has('d') || this.keys.has('arrowright')) - Number(this.keys.has('a') || this.keys.has('arrowleft'));
    if (!forward && !side) return;
    const {world} = this.app;
    let fx = world.controls.target.x - world.camera.position.x;
    let fz = world.controls.target.z - world.camera.position.z;
    const length = Math.hypot(fx, fz) || 1;
    fx /= length;
    fz /= length;
    const norm = Math.hypot(forward, side);
    world.moveTo(world.player.position.x + (fx * forward - fz * side) * 1.5 / norm,
      world.player.position.z + (fz * forward + fx * side) * 1.5 / norm);
  }

  interact() {
    const {game, world, ui} = this.app;
    const player = world.player.position;
    const candidates = game.citizens.map(c => ({kind: 'citizen', ref: c, x: c.x, z: c.z}))
      .concat(places.map(p => ({kind: 'place', ref: p, x: p.x, z: p.z + p.d / 2})));
    candidates.sort((a, b) => Math.hypot(a.x - player.x, a.z - player.z) - Math.hypot(b.x - player.x, b.z - player.z));
    const nearest = candidates[0];
    if (!nearest || Math.hypot(nearest.x - player.x, nearest.z - player.z) > 8) {
      ui.toast('Move closer to a citizen or building.');
      return;
    }
    nearest.kind === 'citizen' ? ui.citizen(nearest.ref) : ui.place(nearest.ref);
  }
}
