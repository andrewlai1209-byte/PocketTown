import {PLACES} from '../data/town.js';

const MOVE_KEYS = ['w', 'a', 's', 'd', 'arrowup', 'arrowleft', 'arrowdown', 'arrowright'];

export class Controls {
  constructor(app) {
    this.app = app;
    this.keys = new Set();
    this.pointer = null;
    this.dragging = null;
    const canvas = app.world.renderer.domElement;
    canvas.addEventListener('pointerdown', event => {
      if (event.button !== 0) return;
      this.pointer = {x: event.clientX, y: event.clientY};
      this.dragging = {x: event.clientX, y: event.clientY};
    });
    canvas.addEventListener('pointermove', event => {
      if (!this.dragging) return;
      const dx = event.clientX - this.dragging.x, dy = event.clientY - this.dragging.y;
      this.dragging = {x: event.clientX, y: event.clientY};
      if (app.game.possessing != null) app.world.lookAround(dx * 2.2, dy * 2.2);
    });
    canvas.addEventListener('pointercancel', () => { this.pointer = null; this.dragging = null; });
    canvas.addEventListener('pointerup', event => {
      const down = this.pointer;
      this.pointer = null;
      this.dragging = null;
      if (!app.active || !down || Math.hypot(event.clientX - down.x, event.clientY - down.y) > 7) return;
      if (app.game.possessing != null) return;                 // inside a head, clicking does not teleport
      const hit = app.world.pick(event.clientX, event.clientY);
      if (!hit) return;
      const {kind, ref} = hit.object.userData;
      if (kind === 'ground') { app.world.moveTo(hit.point.x, hit.point.z); app.ui.close(); }
      else if (kind === 'citizen') app.ui.citizen(ref);
      else if (kind === 'place') app.ui.placePanel(ref);
    });
    addEventListener('keydown', event => {
      if (!app.active || /INPUT|TEXTAREA|SELECT/.test(event.target.tagName)) return;
      const key = event.key.toLowerCase();
      if (MOVE_KEYS.includes(key)) { event.preventDefault(); this.keys.add(key); }
      if (key === 'e' && !event.repeat) this.interact();
      if (key === 'v' && !event.repeat) this.togglePossess();
      if (key === 'f' && !event.repeat) this.toggleWheel();
      if (key === 'r' && !event.repeat) this.teach('reward');
      if (key === 'c' && !event.repeat) this.teach('punish');
      if (key === 'escape') {
        if (app.game.possessing != null) { app.game.unpossess(); app.world.possess(null); app.ui.mind?.hide(); app.ui.close(); }
        else app.ui.close();
      }
    });
    addEventListener('keyup', event => this.keys.delete(event.key.toLowerCase()));
    addEventListener('blur', () => this.keys.clear());
  }

  get vector() {
    const forward = Number(this.keys.has('w') || this.keys.has('arrowup')) - Number(this.keys.has('s') || this.keys.has('arrowdown'));
    const side = Number(this.keys.has('d') || this.keys.has('arrowright')) - Number(this.keys.has('a') || this.keys.has('arrowleft'));
    return {forward, side};
  }

  update() {
    const {forward, side} = this.vector;
    if (!forward && !side) return;
    const {world, game} = this.app;
    if (game.possessing != null && game.minds.wheel) {
      /* the player's keys push on the villager's own command cells, using the direction
         the camera is actually pointing: in this scene forward is (-sin yaw, -cos yaw) */
      const yaw = world.camera.rotation.y;
      const fx = -Math.sin(yaw), fz = -Math.cos(yaw);
      const rx = -fz, rz = fx;
      const norm = Math.hypot(forward, side);
      game.steer((fx * forward + rx * side) / norm, (fz * forward + rz * side) / norm);
      return;
    }
    if (game.possessing != null) return;                        // watching, not driving
    let fx = world.controls.target.x - world.camera.position.x;
    let fz = world.controls.target.z - world.camera.position.z;
    const length = Math.hypot(fx, fz) || 1;
    fx /= length; fz /= length;
    const norm = Math.hypot(forward, side);
    world.moveTo(world.player.position.x + (fx * forward - fz * side) * 1.6 / norm,
      world.player.position.z + (fz * forward + fx * side) * 1.6 / norm);
  }

  nearest() {
    const {game, world} = this.app;
    const from = game.possessing != null ? {x: game.citizens.find(c => c.id === game.possessing).x, z: game.citizens.find(c => c.id === game.possessing).z} : world.player.position;
    const people = game.citizens.map(c => ({kind: 'citizen', ref: c, x: c.x, z: c.z}));
    const places = PLACES.map(p => ({kind: 'place', ref: p, x: p.x, z: p.z + p.d / 2}));
    const candidates = people.concat(places);
    candidates.sort((a, b) => Math.hypot(a.x - from.x, a.z - from.z) - Math.hypot(b.x - from.x, b.z - from.z));
    return candidates[0];
  }

  interact() {
    const {ui, game} = this.app;
    if (game.possessing != null) { ui.mind?.update(); return; }
    const nearest = this.nearest();
    if (!nearest || Math.hypot(nearest.x - this.app.world.player.position.x, nearest.z - this.app.world.player.position.z) > 9) {
      ui.toast('Move closer to a citizen or a building.');
      return;
    }
    nearest.kind === 'citizen' ? ui.citizen(nearest.ref) : ui.placePanel(nearest.ref);
  }

  togglePossess() {
    const {game, world, ui} = this.app;
    if (game.possessing != null) {
      game.unpossess();
      world.possess(null);
      ui.mind?.hide();
      ui.toast('You are yourself again.');
      return;
    }
    const nearest = this.nearest();
    if (!nearest || nearest.kind !== 'citizen') { ui.toast('Stand next to somebody first (V parasises them).'); return; }
    game.possess(nearest.ref.id);
    world.possess(nearest.ref);
    ui.mind?.update();
    ui.toast(`You are inside ${nearest.ref.name}. Keys now nudge their body, not you.`);
  }

  toggleWheel() {
    const {game, ui} = this.app;
    if (game.possessing == null) { ui.toast('Enter a mind first (V).'); return; }
    if (game.minds.wheel) { game.releaseWheel(); ui.toast('You release their motor loop.'); }
    else { game.takeWheel(); ui.toast('You push on their command cells. WASD now steers them.'); }
    ui.mind?.update();
  }

  teach(kind) {
    const {game, ui} = this.app;
    if (game.possessing == null) { ui.toast('Enter a mind (V) to praise or condemn from inside.'); return; }
    const person = game.citizens.find(c => c.id === game.possessing);
    ui.toast(game.talk(person, kind));
    ui.mind?.update();
  }
}
