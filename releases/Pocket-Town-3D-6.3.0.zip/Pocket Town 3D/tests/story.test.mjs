import test from 'node:test';
import assert from 'node:assert/strict';
import {Story} from '../src/story/story.js';
import {newStory,roll} from '../src/story/state.js';
function harness(){const t=Object.create(Story.prototype);t.state=newStory();t.dialog={hidden:false};t.app={ui:{toast(){} }};t.save=()=>{};t.draw=()=>{};t.message=(title,text,actions)=>{t.lastDialog={title,text,actions};};return t;}
test('full evidence path reaches both replayable endings',()=>{for(const ending of ['expose','forgive']){const t=harness();for(const a of ['accept','work','deliver','tool','repair','ledger','verify','council',ending])t.act(a);assert.equal(t.state.stage,6);assert.equal(t.state.ended,true);assert.ok(t.state.clues.includes('shipment ledger'));assert.ok(t.state.clues.includes('witness statement'));assert.equal(t.state.bag.kit,0);assert.ok(t.state.ending.length>30);}});
test('trusting invitation charges money and schedules betrayal',()=>{const t=harness();for(const a of ['accept','work','deliver','tool','repair','ledger','trust'])t.act(a);assert.equal(t.state.stage,6);assert.equal(t.state.risk,14000);assert.ok(t.state.clues.includes('signed accomplice note'));t.act('council');assert.equal(t.lastDialog.title,'An unresolved invitation');assert.equal(t.state.ended,false);});
test('unaffordable trades leave inventory intact and repair needs kit',()=>{const t=harness();t.state.money=0;t.act('tool');assert.equal(t.state.bag.kit,undefined);t.state.stage=3;t.act('repair');assert.equal(t.state.stage,3);});
test('random outcomes persist with saved seed',()=>{const a=newStory();const b=JSON.parse(JSON.stringify(a));assert.equal(roll(a),roll(b));assert.equal(roll(a),roll(b));});
