import * as T from 'three';
import {GLTFExporter} from 'three/addons/exporters/GLTFExporter.js';
import {writeFile} from 'node:fs/promises';
globalThis.FileReader=class {readAsArrayBuffer(blob){blob.arrayBuffer().then(b=>{this.result=b;this.onloadend?.();});}};
const root=new T.Group();root.name='Pocket Town Villager';
const part=(name,size,pos,color)=>{const m=new T.Mesh((name==='Head'?new T.SphereGeometry(.5,24,18).scale(...size):(name==='Coat')?new T.CylinderGeometry(size[0]*.38,size[0]*.31,size[1],20,3):name.startsWith('Arm')||name.startsWith('Leg')?new T.CapsuleGeometry(size[0]/2,Math.max(.05,size[1]-size[0]),12,16):new T.BoxGeometry(...size)),new T.MeshStandardMaterial({color,roughness:.85}));m.name=name;m.position.set(...pos);root.add(m);};
part('Coat',[.58,.82,.34],[0,1.35,0],0x528d85);part('Head',[.48,.55,.45],[0,2.1,0],0xe7b791);part('Hair',[.48,.15,.42],[0,2.39,0],0x45382c);part('Hat',[.38,.08,.36],[0,2.49,0],0x658274);part('Nose',[.09,.12,.12],[0,2.08,.24],0xe7b791);part('Collar',[.25,.12,.2],[0,1.82,.015],0xe4d5bc);part('Scarf',[.62,.1,.37],[0,1.72,.03],0xc66a4f);part('Belt',[.59,.07,.36],[0,.99,0],0x6d5035);part('Apron',[.4,.49,.025],[0,1.28,.218],0xb5a078);part('Jacket seam',[.025,.7,.025],[0,1.36,.22],0xe0d1ad);
for(const s of [-1,1]){part('Leg'+s,[.24,.9,.28],[s*.2,.45,0],0x354452);part('Boot'+s,[.28,.16,.44],[s*.2,.08,.08],0x302d2b);part('Arm'+s,[.22,.8,.26],[s*.53,1.34,0],0x528d85);part('Hand'+s,[.2,.2,.23],[s*.53,.87,0],0xe7b791);part('Eye'+s,[.055,.065,.025],[s*.12,2.14,.235],0x25353a);}
const data=await new GLTFExporter().parseAsync(root,{binary:true});await writeFile('public/models/villager.glb',Buffer.from(data));console.log('Generated local villager GLB:',data.byteLength);
