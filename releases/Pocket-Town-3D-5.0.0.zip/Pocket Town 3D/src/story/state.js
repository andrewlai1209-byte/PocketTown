export const STORY_KEY='pocket-town-story-v1';
export const QUESTS=[
 ['A stranger in town','Speak to Wren at Town Hall. The winter grain has disappeared.','Town Hall'],
 ['Earn your supper','Work a shift at the Farm, then deliver the grain to Mira at the Bakery.','Farm'],
 ['Tools of trust','Buy a repair kit from Finn at the Workshop.','Workshop'],
 ['The broken pump','Repair the pump in the Park.','Park'],
 ['Following the paper trail','Ask Sage for the missing ledger at the Library.','Library'],
 ['A dangerous invitation','Find Leo at the Café. Decide whether to trust his private offer.','Café'],
 ['The winter council','Bring your evidence to Wren at Town Hall. Choose the town’s future.','Town Hall']
];
export function newStory(){return {version:1,stage:0,health:100,food:100,money:30,bag:{},clues:[],relations:{},log:['You arrived in Pocket Town. Find Wren at Town Hall.'],x:0,z:5,yaw:0,pitch:0,elapsed:0,ended:false,ending:'',risk:0,seed:Math.floor(Math.random()*4294967295)};}
export function roll(s){s.seed=(Math.imul(s.seed,1664525)+1013904223)>>>0;return s.seed/4294967296;}
export function readStory(){try{const s=JSON.parse(localStorage.getItem(STORY_KEY));if(s?.version!==1||!Number.isInteger(s.stage)||s.stage<0||s.stage>6||!Number.isFinite(s.health)||!Number.isFinite(s.x)||!Number.isFinite(s.z)||!s.bag||!Array.isArray(s.clues))return null;return s;}catch{return null;}}

export function importStory(text){const s=JSON.parse(text);if(s?.version!==1||!Number.isInteger(s.stage)||s.stage<0||s.stage>6||!['health','food','money','x','z','yaw','pitch','elapsed','risk','seed'].every(k=>Number.isFinite(s[k]))||!Array.isArray(s.clues)||!Array.isArray(s.log)||!s.bag||!s.relations)throw new Error('Choose a Pocket Town story save exported from the journal.');if(s.clues.some(x=>typeof x!=='string')||s.log.some(x=>typeof x!=='string'))throw new Error('Invalid journal data.');const clean=x=>x.replace(/[<>]/g,'');s.clues=s.clues.map(clean);s.log=s.log.map(clean);s.ending=clean(String(s.ending||''));s.bag=Object.fromEntries(Object.entries(s.bag).filter(([k,v])=>/^[a-z]+$/.test(k)&&Number.isFinite(v)&&v>=0));s.x=Math.max(-34,Math.min(34,s.x));s.z=Math.max(-34,Math.min(34,s.z));s.health=Math.max(0,Math.min(100,s.health));s.food=Math.max(0,Math.min(100,s.food));localStorage.setItem(STORY_KEY,JSON.stringify(s));return s;}
