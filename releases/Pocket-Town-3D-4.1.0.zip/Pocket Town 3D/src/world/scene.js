import * as THREE from 'three';
import {OrbitControls} from 'three/addons/controls/OrbitControls.js';
import {PLACES} from '../data/town.js';

const mat = (color, roughness = 1) => new THREE.MeshStandardMaterial({color, roughness});
const clamp = (v, lo, hi) => v < lo ? lo : v > hi ? hi : v;
const G = {
  box: new THREE.BoxGeometry(1, 1, 1),
  sphere: new THREE.SphereGeometry(1, 12, 8),
  cylinder: new THREE.CylinderGeometry(1, 1, 1, 10),
  cone: new THREE.ConeGeometry(1, 1, 4),
};
const ITEM_GLYPH = {bread: '🍞', produce: '🥬', remedy: '🧴', tool: '🔧', cup: '☕', letter: '✉️', flower: '🌼', book: '📖', lesson: '✏️'};
function mesh(geo, color, parent, x, y, z, sx = 1, sy = 1, sz = 1) {
  const o = new THREE.Mesh(geo, typeof color === 'number' ? mat(color) : color);
  o.position.set(x, y, z); o.scale.set(sx, sy, sz); o.castShadow = true; o.receiveShadow = true;
  parent.add(o); return o;
}
function box(parent, color, x, y, z, w, h, d) { return mesh(G.box, color, parent, x, y, z, w, h, d); }

function textSprite(text, {bg = '#ffffffee', fg = '#254352', size = 54, w = 512, h = 128, scale = [5.7, 1.42]} = {}) {
  const c = document.createElement('canvas'); c.width = w; c.height = h;
  const g = c.getContext('2d');
  g.fillStyle = bg; g.beginPath(); g.roundRect(4, 10, w - 8, h - 20, 28); g.fill();
  g.strokeStyle = '#a7c9c1'; g.lineWidth = 5; g.stroke();
  g.fillStyle = fg; g.textAlign = 'center'; g.textBaseline = 'middle';
  g.font = `700 ${size}px system-ui`;
  const words = String(text).split(' ');
  let line = '', lines = [];
  for (const word of words) {
    if (g.measureText(line + ' ' + word).width > w - 60 && line) { lines.push(line); line = word; }
    else line = line ? line + ' ' + word : word;
  }
  lines.push(line);
  lines = lines.slice(0, 3);
  const start = h / 2 - (lines.length - 1) * size * .58;
  lines.forEach((l, i) => g.fillText(l, w / 2, start + i * size * 1.16));
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace;
  const sprite = new THREE.Sprite(new THREE.SpriteMaterial({map: t, depthTest: false, transparent: true}));
  sprite.scale.set(scale[0], scale[1], 1);
  return sprite;
}

function label(text, color = '#254352', size = 64, options = {}) {
  return textSprite(text || ' ', {bg: '#ffffffed', fg: color, size, ...options});
}

function personBody(color) {
  const g = new THREE.Group();
  const pants = 0x4a5967, skin = 0xf2c6a1;
  const torso = mesh(G.cylinder, mat(color), g, 0, 1.4, 0, .62, .65, .4);
  mesh(G.sphere, mat(skin), g, 0, 2.28, 0, .47, .52, .42);
  mesh(G.sphere, mat(0x4c3933), g, 0, 2.62, -.02, .5, .23, .45);
  box(g, pants, -.23, .45, 0, .33, .9, .4);
  box(g, pants, .23, .45, 0, .33, .9, .4);
  box(g, skin, -.72, 1.45, 0, .24, .85, .28);
  box(g, skin, .72, 1.45, 0, .24, .85, .28);
  mesh(G.sphere, mat(0x23343c), g, -.16, 2.3, .39, .045, .055, .025);
  mesh(G.sphere, mat(0x23343c), g, .16, 2.3, .39, .045, .055, .025);
  g.userData.torso = torso;
  return g;
}

function tree(parent, x, z, s = 1) {
  const g = new THREE.Group(); g.position.set(x, 0, z); parent.add(g);
  mesh(G.cylinder, mat(0x806957), g, 0, 1.25, 0, .22, 1.25, .22);
  mesh(G.sphere, mat(0x5da977), g, 0, 3.05, 0, 1.4 * s, 1.3 * s, 1.4 * s);
  mesh(G.sphere, mat(0x80c891), g, -.55, 3.35, .2, .65 * s, .65 * s, .65 * s);
}

function house(parent, x, z, i) {
  const g = new THREE.Group(); g.position.set(x, 0, z); parent.add(g);
  box(g, [0xdcc5ae, 0xe2d3b8, 0xd4cabc][i % 3], 0, 1.8, 0, 5, 3.6, 4.6);
  const roof = mesh(G.cone, [0xa78280, 0x879eac, 0x9d8f83][i % 3], g, 0, 4.55, 0, 4.1, 1.65, 4.1);
  roof.rotation.y = Math.PI / 4;
  box(g, 0x644e46, 0, .85, 2.34, .9, 1.7, .12);
  box(g, 0xa2d7d8, -1.4, 2.15, 2.34, .8, .9, .14);
  box(g, 0xa2d7d8, 1.4, 2.15, 2.34, .8, .9, .14);
  return g;
}

const SKY = {
  dawn: new THREE.Color(0xf4c9a1), day: new THREE.Color(0xb9dce2),
  dusk: new THREE.Color(0xe3a37b), night: new THREE.Color(0x2c3f5a),
};

export class World {
  constructor(container, game) {
    this.game = game;
    this.container = container;
    this.scene = new THREE.Scene();
    this.scene.background = SKY.day.clone();
    this.scene.fog = new THREE.Fog(SKY.day.clone(), 85, 150);
    this.camera = new THREE.PerspectiveCamera(52, 1, .1, 320);
    this.camera.position.set(48, 45, 54);
    this.renderer = new THREE.WebGLRenderer({antialias: true, powerPreference: 'high-performance'});
    this.renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    container.appendChild(this.renderer.domElement);
    this.controls = new OrbitControls(this.camera, this.renderer.domElement);
    this.controls.target.set(0, 0, 2);
    this.controls.enableDamping = true;
    this.controls.maxPolarAngle = Math.PI * .48;
    this.controls.minDistance = 20;
    this.controls.maxDistance = 110;
    this.controls.update();
    this.raycaster = new THREE.Raycaster();
    this.pointer = new THREE.Vector2();
    this.pickables = [];
    this.bodies = [];
    this.bubbles = [];
    this.icons = [];
    this.possessing = null;
    this.look = {yaw: 0, pitch: 0};
    this.destination = null;
    this.time = 0;
    this.build();
    this.resize();
    addEventListener('resize', () => this.resize());
  }

  resize() {
    const p = this.renderer.domElement.parentElement;
    const w = p.clientWidth, h = p.clientHeight;
    /* an embedded preview can report an empty box while it is being laid out; feeding a zero
       or NaN aspect into the projection matrix would blank the whole scene */
    if (!(w > 0 && h > 0)) return;
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(w, h);
  }

  build() {
    this.ambient = new THREE.HemisphereLight(0xf5fbff, 0x739d7c, 2.2);
    this.scene.add(this.ambient);
    this.sun = new THREE.DirectionalLight(0xfff2d2, 3);
    this.sun.position.set(-25, 50, -18);
    this.sun.castShadow = true;
    this.sun.shadow.mapSize.set(2048, 2048);
    Object.assign(this.sun.shadow.camera, {left: -65, right: 65, top: 65, bottom: -65});
    this.sun.shadow.normalBias = .02;
    this.scene.add(this.sun);

    const ground = box(this.scene, 0x9ccc96, 0, -.55, 0, 75, 1, 75);
    ground.userData = {kind: 'ground'};
    this.pickables.push(ground);
    for (let i = -3; i <= 3; i++) {
      const a = i * 8;
      box(this.scene, 0xc8d1cf, a, .03, 0, 2, .08, 72);
      box(this.scene, 0xc8d1cf, 0, .035, a, 72, .08, 2);
    }
    for (let i = -3; i <= 3; i++) for (let j = -3; j <= 3; j++) {
      const a = i * 8, b = j * 8;
      box(this.scene, 0xf5f0de, a, .085, b, 1, .012, .18);
      box(this.scene, 0xf5f0de, a, .085, b, .18, .012, 1);
    }
    const park = box(this.scene, 0x86c995, 1, .03, 9, 14, .08, 11);
    park.userData = {kind: 'ground'};
    this.pickables.push(park);
    mesh(G.cylinder, 0x8bc8d8, this.scene, 1, .15, 9, 2.4, .12, 1.8);
    for (let i = 0; i < 7; i++) tree(this.scene, Math.cos(i * Math.PI * 2 / 7) * 6 + 1, Math.sin(i * Math.PI * 2 / 7) * 4 + 9, .8);

    const homes = [[-28, -26], [-19, -26], [19, -26], [28, -26], [-28, 0], [28, 0], [-28, 29], [-19, 29], [19, 29], [28, 29]];
    homes.forEach(([x, z], i) => house(this.scene, x, z, i));
    for (let i = 0; i < 60; i++) {
      const x = Math.sin(i * 74.3) * 35, z = Math.cos(i * 17.7) * 35;
      if (Math.abs(x) < 31 && Math.abs(z) < 32) continue;
      tree(this.scene, x, z, .7 + (i % 4) * .11);
    }

    for (const p of PLACES) {
      const group = new THREE.Group();
      group.position.set(p.x, 0, p.z);
      this.scene.add(group);
      if (p.type === 'park') {
        const sign = label(p.name); sign.position.set(0, 4.2, 0); group.add(sign);
        sign.userData = {kind: 'place', ref: p};
        this.pickables.push(sign);
        continue;
      }
      box(group, p.color, 0, p.h / 2, 0, p.w, p.h, p.d);
      const roof = mesh(G.cone, p.roof, group, 0, p.h + 1.6, 0, Math.max(p.w, p.d) * .72, 2, Math.max(p.w, p.d) * .72);
      roof.rotation.y = Math.PI / 4;
      box(group, 0x665448, 0, 1.25, p.d / 2 + .09, 1.6, 2.5, .25);
      for (const side of [-1, 1]) {
        box(group, 0xa8d5d8, side * p.w * .28, p.h * .54, p.d / 2 + .08, 1.4, 1.6, .2);
        box(group, 0xfaf0da, side * p.w * .28, p.h * .54, p.d / 2 + .2, .08, 1.75, .08);
      }
      const sign = label(p.name);
      sign.position.set(0, p.h + 3.3, p.d / 2);
      group.add(sign);
      group.traverse(o => {
        if (o.isMesh) { o.userData = {kind: 'place', ref: p}; this.pickables.push(o); }
      });
    }

    for (const c of this.game.citizens) {
      const body = personBody(c.color);
      body.position.set(c.x, 0, c.z);
      this.scene.add(body);
      const tag = label(c.name, '#325064', 50);
      tag.scale.set(3.3, .85, 1);
      tag.position.y = 3.55;
      body.add(tag);
      const bubble = label('', '#2b4c5e', 40, {scale: [4.6, 1.5]});
      bubble.position.y = 5.1;
      bubble.visible = false;
      body.add(bubble);
      const item = label('', '#5d4a2f', 46, {bg: '#fff6dd', scale: [1.7, .9]});
      item.position.set(1.05, 1.85, 0);
      item.visible = false;
      body.add(item);
      const halo = new THREE.Sprite(new THREE.SpriteMaterial({map: haloTexture(), transparent: true, depthTest: false}));
      halo.scale.set(2.2, 2.2, 1);
      halo.position.y = 1.5;
      halo.visible = false;
      body.add(halo);
      body.traverse(o => {
        if (o.isMesh) { o.userData = {kind: 'citizen', ref: c}; this.pickables.push(o); }
      });
      this.bodies.push(body);
      this.bubbles.push(bubble);
      this.icons.push(item);
      body.userData.halo = halo;
      body.userData.tag = tag;
    }

    this.player = personBody(0xf5a65d);
    this.player.position.set(this.game.playerPosition.x, 0, this.game.playerPosition.z);
    this.scene.add(this.player);
    const you = label('YOU', '#5e7050', 50);
    you.scale.set(2.2, .7, 1); you.position.y = 3.65;
    this.player.add(you);
  }

  pick(x, y) {
    const rect = this.renderer.domElement.getBoundingClientRect();
    this.pointer.set((x - rect.left) / rect.width * 2 - 1, -(y - rect.top) / rect.height * 2 + 1);
    this.raycaster.setFromCamera(this.pointer, this.camera);
    const hits = this.raycaster.intersectObjects(this.pickables, false);
    return hits.find(h => h.object.userData?.kind) || null;
  }

  moveTo(x, z) {
    if (this.possessing != null) return;
    this.destination = new THREE.Vector3(clamp(x, -35, 35), 0, clamp(z, -35, 35));
  }

  possess(person) {
    this.possessing = person ? person.id : null;
    this.look = {yaw: 0, pitch: 0};
    this.controls.enabled = !person;
    this.container.classList.toggle('inside', !!person);
    if (!person) {
      this.camera.fov = 52;
      this.camera.rotation.set(0, 0, 0);
      this.camera.up.set(0, 1, 0);
      this.camera.position.set(40, 38, 46);
      this.controls.target.set(this.game.playerPosition.x, 1, this.game.playerPosition.z);
      this.controls.update();
    }
    this.camera.updateProjectionMatrix();
  }

  lookAround(dx, dy) {
    if (this.possessing == null) return;
    this.look.yaw -= dx * .004;
    this.look.pitch = clamp(this.look.pitch - dy * .003, -.55, .5);
  }

  updateSky(hour) {
    const t = hour;
    let sky, sunStrength, ambient;
    if (t < 5.5 || t > 21) { sky = SKY.night; sunStrength = .25; ambient = .5; }
    else if (t < 8) { const k = (t - 5.5) / 2.5; sky = SKY.dawn.clone().lerp(SKY.day, k); sunStrength = .8 + k * 2; ambient = .9 + k; }
    else if (t > 18) { const k = clamp((t - 18) / 3, 0, 1); sky = SKY.day.clone().lerp(SKY.dusk, k); sunStrength = 2.9 - k * 2.4; ambient = 2 - k; }
    else { sky = SKY.day; sunStrength = 3; ambient = 2.2; }
    this.scene.background.copy(sky);
    this.scene.fog.color.copy(sky);
    this.sun.intensity = sunStrength;
    this.ambient.intensity = ambient;
    const angle = (t / 24) * Math.PI * 2 - Math.PI / 2;
    this.sun.position.set(Math.cos(angle) * 55, Math.max(8, Math.sin(angle) * 55 + 25), -20);
  }

  update(dt) {
    const state = this.game.state;
    const hour = state.minute / 60;
    this.time += dt;
    this.updateSky(hour);

    this.game.citizens.forEach((c, i) => {
      const body = this.bodies[i];
      const bobbing = Math.abs(c.speed) > .08;
      body.position.set(c.x, bobbing ? Math.abs(Math.sin(this.time * .009 + i)) * .09 : 0, c.z);
      body.rotation.y = c.heading;
      const torso = body.userData.torso;
      if (torso) {
        const tint = new THREE.Color(c.color);
        if (c.mood < .35) tint.lerp(new THREE.Color(0x5d6b7d), .35);
        else if (c.brain.da > .5) tint.lerp(new THREE.Color(0xf6d488), .22);
        torso.material.color.copy(tint);
      }
      const halo = body.userData.halo;
      const buzz = clamp(c.brain.channels.arousal * (.4 + c.brain.da + c.brain.oa) * 1.3, 0, 1);
      halo.visible = buzz > .12 || c.id === this.possessing;
      if (halo.visible) {
        halo.material.opacity = .18 + buzz * .5;
        halo.scale.setScalar(2 + buzz * 1.5);
        halo.material.color.set(c.brain.oa > c.brain.da ? 0xff8f7a : 0x9de3c9);
      }
      const bubble = this.bubbles[i];
      const speaking = c.speech && c.speech.until > performance.now();
      if (speaking) {
        if (bubble.userData.text !== c.speech.text) {
          bubble.material.map?.dispose();
          bubble.material.dispose();
          const next = textSprite(c.speech.text, {bg: '#ffffffe6', fg: '#24414f', size: 38, scale: [5, 1.6]});
          bubble.material = next.material;
          bubble.userData.text = c.speech.text;
        }
        bubble.visible = true;
        bubble.scale.set(5, 1.6, 1);
      } else bubble.visible = false;

      const icon = this.icons[i];
      const held = Object.keys(c.inventory).find(k => c.inventory[k] > 0);
      if (held) {
        const glyph = `${ITEM_GLYPH[held] || '📦'}${c.inventory[held]}`;
        if (icon.userData.text !== glyph) {
          icon.material.map?.dispose();
          icon.material.dispose();
          const next = textSprite(glyph, {bg: '#fff6ddee', fg: '#5b4a2b', size: 62, w: 256, h: 128, scale: [1.5, .75]});
          icon.material = next.material;
          icon.userData.text = glyph;
        }
        icon.visible = true;
      } else icon.visible = false;
    });

    if (this.possessing != null) {
      const c = this.game.citizens.find(x => x.id === this.possessing);
      if (c) {
        const bob = Math.abs(c.speed) > .08 ? Math.sin(this.time * .012) * .07 : 0;
        this.camera.position.set(c.x + Math.sin(c.heading) * .25, 2.5 + bob, c.z + Math.cos(c.heading) * .25);
        this.camera.rotation.order = 'YXZ';
        const goLeft = c.brain.channels.roll * .35;
        this.camera.rotation.y = c.heading + this.look.yaw + goLeft * .1;
        this.camera.rotation.x = this.look.pitch - .04;
        this.camera.fov = 62 + c.brain.channels.arousal * 8;
        this.camera.updateProjectionMatrix();
        this.player.visible = false;
      }
    } else {
      this.player.visible = true;
      if (this.destination) {
        const d = this.destination.clone().sub(this.player.position);
        d.y = 0;
        if (d.length() < .25) this.destination = null;
        else {
          const speed = Math.min(d.length(), dt * .012);
          this.player.rotation.y = Math.atan2(d.x, d.z);
          this.player.position.add(d.normalize().multiplyScalar(speed));
        }
      }
      this.game.playerPosition.x = this.player.position.x;
      this.game.playerPosition.z = this.player.position.z;
      this.controls.update();
    }
    this.renderer.render(this.scene, this.camera);
  }
}

let haloCache = null;
function haloTexture() {
  if (haloCache) return haloCache;
  const c = document.createElement('canvas'); c.width = c.height = 128;
  const g = c.getContext('2d');
  const grad = g.createRadialGradient(64, 64, 8, 64, 64, 62);
  grad.addColorStop(0, 'rgba(255,255,255,.95)');
  grad.addColorStop(.55, 'rgba(160,230,210,.35)');
  grad.addColorStop(1, 'rgba(160,230,210,0)');
  g.fillStyle = grad; g.fillRect(0, 0, 128, 128);
  haloCache = new THREE.CanvasTexture(c);
  return haloCache;
}
