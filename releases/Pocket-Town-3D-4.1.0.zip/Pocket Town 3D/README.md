# Pocket Town 3D — Twelve Real Brains

A 3D town where every citizen is run by the real *C. elegans* connectome, compiled out of
the OpenWorm c302 project: **285 spiking neurons, 163 muscles, 7,379 connections per mind**.
They smell food, feel contact, hear neighbours, trade, promise, gossip, cheat, get punished
for it — and their synapses change according to what reward and punishment taught them.

You can also slip inside one of them and watch a life from the inside.

## Play the included build

1. Extract the ZIP completely into a folder.
2. Install Node.js 20.19+ if it is not already available.
3. Double-click **Start Game.cmd** on Windows.
4. Keep the launcher window open while playing. The game opens in your browser.

The included build needs no `npm install` and no internet. The launcher serves `dist/`
through a local read-only server on port 4173 (it picks another port if needed). Stop with
Ctrl+C in the launcher window. On macOS or Linux: `node scripts/serve.mjs --open`.

Do not open the HTML file directly; the game loads several modules and must be served.

## What the town does by itself

Every citizen keeps their own hours. On shift they walk to a station at their own workplace
and work the yard; when the shift ends they go to whichever of their haunts has somebody in
it; at night, or when they are spent, they walk home and sleep. Speed **1** is a real walking
pace — about 2.5 town units per second, so a crossing of the square takes a few seconds and a
work shift lasts a morning. Watch one villager from the citizen card ("Enter their mind") and
you will see the day happen: they leave the house, meet someone on the way, stop, turn to
face them, answer, then finish the walk to the Bakery.

The simulation is driven by a timer as well as by the paint loop, so a page that reports itself
hidden — an embedded preview, an occluded window, a background tab — keeps living instead of
freezing. If the town ever looks motionless, check the speed readout in the header rather than
the clock: at **1×** one town-day is six real minutes.

## Controls

Outside a head:

- Drag orbit, scroll zoom, **WASD** or arrows to walk, click ground to walk there.
- Click a citizen or building, or press **E**, to interact.
- **👥 Society** shows promises, betrayals, rumours and each villager's ledger;
  **🧠 Brains** explains exactly which OpenWorm data is running and what is simplified.

Inside a head (press **V** next to somebody):

- The camera takes their eyes and their gait; drag to look around.
- The left panel is live: what their body senses, their drives, motor readout from real
  muscle groups, the five learned character numbers, the ranked urges competing for
  control, a spike raster of named neurons, amine tone, trust, memories.
- **F** takes their motor loop: your keys push on their own command cells. They can resist,
  and holding on drains their willpower.
- **R** praises, **C** condemns. Both are teaching signals — they change which synapses get
  stronger or weaker, so tomorrow this villager is slightly different.
- **Esc** or **V** leaves them alone.
- **ⓘ About** explains the game, research context, implementation and data resources.

Progress saves in your browser, including every villager's learned synaptic weights.

## Training a town

Nothing here is scripted as "be honest". A villager keeps a promise when their braking
wiring, the trust they hold for you, and the credit from past kept promises outweigh the
temptation of the goods in their hands. Keep the town rewarding — gifts, praise, delivered
promises — and neighbours who cheat get shunned, accused and denied trade. Punishment is
octopamine; reward is dopamine; both are the animal's own cells.

Trade, theft, gossip and confession all work the same way: two nervous systems meeting,
each deciding from its own history.

## Editing the project

```bash
npm install
npm run dev        # Vite development entry
npm run brain      # rebuild src/data/connectome.gen.js from the OpenWorm c302 folder
npm test           # 21 regression checks on the brain and on town life
npm run build      # playable multi-file build in dist/
npm run package    # build plus releases/Pocket-Town-3D-*.zip
```

`npm run brain` reads `herm_full_edgelist.csv`, `owmeta_cache.json` and
`Bentley_et_al_2016_expression.csv` from the OpenWorm c302 folder (path passed as an
argument, default `../OpenWorm c302/c302` on this machine). It adds no connections and
invents no cells; it prints what it interpreted.

See [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) for the module map and an honest list of
what is real data versus what is modelled. Third-party licences are in `licenses/`.

Citizen decisions come from their nervous systems; the words come from hand-authored voice
packs in `src/data/voices/`. No online AI account or API key is required.
