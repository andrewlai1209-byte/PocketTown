import * as T from 'three';
import {GLTFExporter} from 'three/addons/exporters/GLTFExporter.js';
import {writeFile} from 'node:fs/promises';
globalThis.FileReader=class {readAsArrayBuffer(blob){blob.arrayBuffer().then(b=>{this.result=b;this.onloadend?.();});}};
const root=new T.Group();root.name='Pocket Town Villager';
const part=(name,size,pos,color)=>{const m=new T.Mesh(new T.BoxGeometry(...size),new T.MeshStandardMaterial({color,roughness:.85}));m.name=name;m.position.set(...pos);root.add(m);};
part('Coat',[.72,.85,.42],[0,1.35,0],0x528d85);part('Head',[.48,.55,.45],[0,2.1,0],0xe7b791);part('Hair',[.52,.18,.49],[0,2.39,0],0x45382c);
for(const s of [-1,1]){part('Leg'+s,[.24,.9,.28],[s*.2,.45,0],0x354452);part('Boot'+s,[.28,.16,.44],[s*.2,.08,.08],0x302d2b);part('Arm'+s,[.22,.8,.26],[s*.53,1.34,0],0x528d85);part('Hand'+s,[.2,.2,.23],[s*.53,.87,0],0xe7b791);part('Eye'+s,[.055,.065,.025],[s*.12,2.14,.235],0x25353a);}
const data=await new GLTFExporter().parseAsync(root,{binary:true});await writeFile('public/models/villager.glb',Buffer.from(data));console.log('Generated local villager GLB:',data.byteLength);
